package com.arshilgenius.kisan.agriculture;

/**
 * Created by humra on 2/10/2017.
 */
public class foru {

  private String post;
  private String time;


    long stackId;
    public foru() {
      /*Blank default constructor essential for Firebase*/
    }
    public foru(String a)
    {

    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }


  //Getters and setters

}

