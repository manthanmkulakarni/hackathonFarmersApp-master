package com.arshilgenius.kisan.agriculture.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.arshilgenius.kisan.agriculture.R;

public class Wheat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wheat);
    }
}
