package com.arshilgenius.kisan.agriculture;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class DiseasePredict extends AppCompatActivity {

    WebView wb1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disease_predict);

        wb1=(WebView)findViewById(R.id.webview10);

        wb1.getSettings().setJavaScriptEnabled(true);
        wb1.loadUrl("https://fitness2-79df1.firebaseapp.com");
    }
}
