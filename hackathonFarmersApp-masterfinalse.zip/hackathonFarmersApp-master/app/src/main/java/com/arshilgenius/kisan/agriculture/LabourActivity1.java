package com.arshilgenius.kisan.agriculture;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LabourActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_labour1);
    }
}
